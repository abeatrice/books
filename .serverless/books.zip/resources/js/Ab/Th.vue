<template>
    <th class="px-6 py-3 text-left font-medium">
        <slot></slot>
    </th>
</template>

<script>
    export default {
    }
</script>
