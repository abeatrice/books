<template>
    <td class="px-6 py-4">
        <slot></slot>
    </td>
</template>

<script>
    export default {
    }
</script>
