<template>
    <button class="focus:outline-none"><slot></slot></button>
</template>

<script>
    export default {
    }
</script>
